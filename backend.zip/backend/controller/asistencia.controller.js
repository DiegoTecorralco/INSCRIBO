import asistenciaDAO from "../dao/asistencia.dao.js";
import clasesDAO from "../dao/clases.dao.js";
import GrupoDAO from "../dao/grupos.dao.js"; // Importa el GrupoDAO
import moment from "moment-timezone";

const asistenciaController = {};

// 🔹 Función interna que permite registrar asistencia sin req y res
asistenciaController.registrarAsistenciaInterno = async (idProgramado) => {
  try {
    console.log("Inicio de registrarAsistenciaInterno");
    console.log("Buscando al estudiante con matrícula:", idProgramado);

    const estudiante = await GrupoDAO.buscarEstudiantePorMatricula(idProgramado);
    console.log("Resultado de buscarEstudiantePorMatricula:", estudiante);

    if (!estudiante) {
      console.log("Estudiante no encontrado en ningún grupo.");
      return { error: "Estudiante no encontrado en ningún grupo" };
    }

    console.log("Estudiante encontrado:", estudiante);

    // Obtener el día actual en español
    const diaActual = moment().tz("America/Mexico_City").format("dddd").toLowerCase();
    console.log("Día actual (moment):", diaActual);

    // Buscar las clases de hoy
    const clasesHoy = await clasesDAO.obtenerClasesPorDia(diaActual);
    console.log("Resultado de obtenerClasesPorDia:", clasesHoy);

    const horaActual = moment().tz("America/Mexico_City").format("HH:mm");
    console.log("Hora actual:", horaActual);

    let claseActual = null;
    for (const dia of clasesHoy) {
      for (const clase of dia.clases) {
        const [inicioClase] = clase.horario.split("-");
        const diferenciaMinutos = moment(horaActual, "HH:mm").diff(moment(inicioClase, "HH:mm"), "minutes");

        if (diferenciaMinutos >= 0 && diferenciaMinutos <= 10) {
          claseActual = clase;
          break;
        }
      }
      if (claseActual) break;
    }

    console.log("Clase actual encontrada:", claseActual || "No hay clase en este horario");

    // Determinar tipo de asistencia
    let tipoAsistencia = "asistencia";
    if (claseActual) {
      const [inicioClase] = claseActual.horario.split("-");
      const diferenciaMinutos = moment(horaActual, "HH:mm").diff(moment(inicioClase, "HH:mm"), "minutes");
      tipoAsistencia = diferenciaMinutos > 5 ? "retardo" : "asistencia";
    }

    console.log("Tipo de asistencia determinado:", tipoAsistencia);

    // Registrar la asistencia en la BD
    const asistencia = await asistenciaDAO.registrarAsistencia({
      idProgramado,
      nombre: estudiante.nombre,
      materia: claseActual?.materia || "Sin materia",
      grupo: estudiante.grupo || "Desconocido", // ✅ Asegura que el grupo no sea undefined
      maestro: claseActual?.maestro || "Desconocido",
      horario: claseActual?.horario || "Sin horario",
      tipoAsistencia,
    });

    console.log("Asistencia registrada exitosamente:", asistencia);

    return asistencia;
  } catch (error) {
    console.error("Error en el pase de lista:", error);
    return { error: "Error interno del servidor" };
  }
};

// 🔹 Método principal que usa req y res (para las rutas)
asistenciaController.registrarAsistencia = async (req, res) => {
  console.log("Inicio de registrarAsistencia");
  const { idProgramado } = req.body;
  console.log("ID programado recibido:", idProgramado);

  const result = await asistenciaController.registrarAsistenciaInterno(idProgramado);

  if (result.error) {
    console.log("Error al registrar asistencia:", result.error);
    return res.status(404).json({ message: result.error });
  }

  console.log("Asistencia registrada con éxito:", result);
  res.status(201).json({ message: "Asistencia registrada", asistencia: result });
};

export default asistenciaController;
