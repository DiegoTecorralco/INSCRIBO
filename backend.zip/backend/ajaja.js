[
    {"matricula": "220773", "nombre": "Artiaga Quiroga Ailton"},
    {"matricula": "230693", "nombre": "Balderas Gomez Dulce"},
    {"matricula": "220397", "nombre": "Bravo Godinez Daniel De Jesús"},
    {"matricula": "230496", "nombre": "Cabrera Velázquez Edgar"},
    {"matricula": "230346", "nombre": "Estrada Jiménez Jesús Antonio"},
    {"matricula": "230315", "nombre": "Flores Campos Osvaldo Abishai"},
    {"matricula": "230335", "nombre": "Fosado Escudero Carlos Isaac"},
    {"matricula": "230298", "nombre": "Gallindo Gonzalez Lorena Citlalli"},
    {"matricula": "230376", "nombre": "González Peralta Esther"},
    {"matricula": "230309", "nombre": "Guzmán Barrera Abril"},
    {"matricula": "230369", "nombre": "Ibarra Salgado Tania"},
    {"matricula": "230365", "nombre": "Jimenez Castillo José Agustin"},
    {"matricula": "230308", "nombre": "Leon Cabrera Brandon"},
    {"matricula": "230642", "nombre": "López Neri Ana Daniela"},
    {"matricula": "230410", "nombre": "Martinez Otero Josué Atila"},
    {"matricula": "230373", "nombre": "Medina Torres Uriel Abdala"},
    {"matricula": "230809", "nombre": "Mendoza Marquez Brian Jesus"},
    {"matricula": "230570", "nombre": "Negrete Hernández Karen Lizbeth"},
    {"matricula": "230642", "nombre": "Ocpaco Dolores Antonio"},
    {"matricula": "230410", "nombre": "Ramirez Reyes Jonathan Baldemar"},
    {"matricula": "230373", "nombre": "Ríos Durán Marcos Jesus"},
    {"matricula": "230809", "nombre": "Rodriguez Perez Christian Paul"},
    {"matricula": "230190", "nombre": "Romero Martinez Yared Amaury"},
    {"matricula": "230499", "nombre": "Rufino Mendoza Angel De Jesús"},
    {"matricula": "230574", "nombre": "Tecorralco Martinez Diego Salvador"},
    {"matricula": "230196", "nombre": "Vargas Galindo Guadalupe Idai"},
    {"matricula": "230852", "nombre": "Viveros Martinez Juvenal"},
    {"matricula": "230852", "nombre": "Zacateco Pedroza Zayana Ahuactli"}
  ]
  


  [
    {
      "_id": "ObjectId(\"67e0946532daedbaaea1890e\")",
      "nombre": "GrupoA",
      "estudiantes": [
        {"matricula": "220773", "nombre": "Artiaga Quiroga Ailton"},
        {"matricula": "230693", "nombre": "Balderas Gomez Dulce"},
        {"matricula": "220397", "nombre": "Bravo Godinez Daniel De Jesús"},
        {"matricula": "230496", "nombre": "Cabrera Velázquez Edgar"}
        
      ]
    },
    {
      "_id": "ObjectId(\"67e0946532daedbaaea1890f\")",
      "nombre": "GrupoB",
      "estudiantes": [
        {"matricula": "240101", "nombre": "Hernández López Mariana"},
        {"matricula": "240102", "nombre": "Ramírez Sánchez Carlos"},
        {"matricula": "240103", "nombre": "Gómez Torres Sofía"},
        {"matricula": "240104", "nombre": "Martínez Jiménez Javier"},
        {"matricula": "240105", "nombre": "Pérez Cruz Valeria"}
      ]
    }
  ]
  